-- PharmaTrack Database Schema
-- Run this script in MySQL before starting the application

CREATE DATABASE IF NOT EXISTS pharmatrack_db;
USE pharmatrack_db;

-- USER TABLE
CREATE TABLE IF NOT EXISTS users (
    userID VARCHAR(20) PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    passwordHash VARCHAR(255) NOT NULL,
    role ENUM('Admin', 'User') NOT NULL DEFAULT 'User'
);

-- PRODUCT TABLE
CREATE TABLE IF NOT EXISTS products (
    productID VARCHAR(20) PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    expirationDate DATE
);

-- STOCK TABLE
CREATE TABLE IF NOT EXISTS stock (
    stockID VARCHAR(20) PRIMARY KEY,
    productID VARCHAR(20) NOT NULL,
    stqQuantity INT NOT NULL DEFAULT 0,
    price DOUBLE NOT NULL DEFAULT 0.0,
    expirationDate DATE,
    FOREIGN KEY (productID) REFERENCES products(productID) ON DELETE CASCADE
);

-- TRANSACTION TABLE
CREATE TABLE IF NOT EXISTS transactions (
    transactionID VARCHAR(20) PRIMARY KEY,
    productID VARCHAR(20) NOT NULL,
    date DATE NOT NULL,
    quantity INT NOT NULL,
    totalPrice DOUBLE NOT NULL,
    paymentType VARCHAR(50),
    userID VARCHAR(20) NOT NULL,
    FOREIGN KEY (productID) REFERENCES products(productID),
    FOREIGN KEY (userID) REFERENCES users(userID)
);

-- TRANSACTION ITEM TABLE
CREATE TABLE IF NOT EXISTS transaction_items (
    transactionItemID VARCHAR(20) PRIMARY KEY,
    transactionID VARCHAR(20) NOT NULL,
    productID VARCHAR(20) NOT NULL,
    transactionItemQuantity INT NOT NULL,
    price DOUBLE NOT NULL,
    subTotal DOUBLE NOT NULL,
    FOREIGN KEY (transactionID) REFERENCES transactions(transactionID),
    FOREIGN KEY (productID) REFERENCES products(productID)
);

-- REPORT TABLE
CREATE TABLE IF NOT EXISTS reports (
    reportID VARCHAR(20) PRIMARY KEY,
    dateGenerated DATE NOT NULL,
    totalSales DOUBLE NOT NULL DEFAULT 0.0,
    totalTransactions INT NOT NULL DEFAULT 0,
    lowStockItems TEXT
);

-- Default admin account (username: admin, password: admin123)
INSERT IGNORE INTO users (userID, username, passwordHash, role)
VALUES ('USR001', 'admin', 'admin123', 'Admin');

INSERT IGNORE INTO users (userID, username, passwordHash, role)
VALUES ('USR002', 'user', 'user123', 'User');
