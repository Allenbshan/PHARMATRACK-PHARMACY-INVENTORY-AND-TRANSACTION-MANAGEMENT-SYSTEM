package com.pharmatrack.dao;

import com.pharmatrack.db.DatabaseConnection;
import com.pharmatrack.model.Transaction;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TransactionDAO {

    public boolean createTransaction(Transaction txn) {
        String sql = "INSERT INTO transactions (transactionID, productID, date, quantity, totalPrice, paymentType, userID) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, txn.getTransactionID());
            ps.setString(2, txn.getProductID());
            ps.setDate(3, txn.getDate());
            ps.setInt(4, txn.getQuantity());
            ps.setDouble(5, txn.getTotalPrice());
            ps.setString(6, txn.getPaymentType());
            ps.setString(7, txn.getUserID());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateTransaction(Transaction txn) {
        String sql = "UPDATE transactions SET productID = ?, quantity = ?, totalPrice = ?, paymentType = ? WHERE transactionID = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, txn.getProductID());
            ps.setInt(2, txn.getQuantity());
            ps.setDouble(3, txn.getTotalPrice());
            ps.setString(4, txn.getPaymentType());
            ps.setString(5, txn.getTransactionID());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Transaction> getAllTransactions() {
        List<Transaction> list = new ArrayList<>();
        String sql = "SELECT t.*, p.name AS productName FROM transactions t JOIN products p ON t.productID = p.productID ORDER BY t.date DESC, t.transactionID DESC";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                Transaction txn = new Transaction(
                        rs.getString("transactionID"),
                        rs.getString("productID"),
                        rs.getDate("date"),
                        rs.getInt("quantity"),
                        rs.getDouble("totalPrice"),
                        rs.getString("paymentType"),
                        rs.getString("userID")
                );
                txn.setProductName(rs.getString("productName"));
                list.add(txn);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Transaction> getTransactionsByDate(java.sql.Date date) {
        List<Transaction> list = new ArrayList<>();
        String sql = "SELECT t.*, p.name AS productName FROM transactions t JOIN products p ON t.productID = p.productID WHERE t.date = ? ORDER BY t.transactionID";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDate(1, date);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Transaction txn = new Transaction(
                        rs.getString("transactionID"),
                        rs.getString("productID"),
                        rs.getDate("date"),
                        rs.getInt("quantity"),
                        rs.getDouble("totalPrice"),
                        rs.getString("paymentType"),
                        rs.getString("userID")
                );
                txn.setProductName(rs.getString("productName"));
                list.add(txn);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public double getTotalSalesByDate(java.sql.Date date) {
        String sql = "SELECT COALESCE(SUM(totalPrice), 0) FROM transactions WHERE date = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDate(1, date);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getDouble(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0.0;
    }

    public int getTotalTransactionsByDate(java.sql.Date date) {
        String sql = "SELECT COUNT(*) FROM transactions WHERE date = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDate(1, date);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public String generateNextTransactionID() {
        String sql = "SELECT transactionID FROM transactions ORDER BY transactionID DESC LIMIT 1";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            if (rs.next()) {
                String last = rs.getString("transactionID");
                int num = Integer.parseInt(last.replaceAll("[^0-9]", "")) + 1;
                return String.format("TXN%03d", num);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "TXN001";
    }
}
