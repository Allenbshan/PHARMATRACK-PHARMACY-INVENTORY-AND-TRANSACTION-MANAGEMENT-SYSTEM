package com.pharmatrack.dao;

import com.pharmatrack.db.DatabaseConnection;
import com.pharmatrack.model.Stock;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StockDAO {

    public boolean addStock(Stock stock) {
        String sql = "INSERT INTO stock (stockID, productID, stqQuantity, price, expirationDate) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, stock.getStockID());
            ps.setString(2, stock.getProductID());
            ps.setInt(3, stock.getStqQuantity());
            ps.setDouble(4, stock.getPrice());
            ps.setDate(5, stock.getExpirationDate());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateStock(Stock stock) {
        String sql = "UPDATE stock SET stqQuantity = ?, price = ?, expirationDate = ? WHERE stockID = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, stock.getStqQuantity());
            ps.setDouble(2, stock.getPrice());
            ps.setDate(3, stock.getExpirationDate());
            ps.setString(4, stock.getStockID());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deleteStock(String stockID) {
        String sql = "DELETE FROM stock WHERE stockID = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, stockID);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Stock> getAllStock() {
        List<Stock> list = new ArrayList<>();
        String sql = "SELECT s.*, p.name AS productName FROM stock s JOIN products p ON s.productID = p.productID ORDER BY s.stockID";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                Stock stock = new Stock(
                        rs.getString("stockID"),
                        rs.getString("productID"),
                        rs.getInt("stqQuantity"),
                        rs.getDouble("price"),
                        rs.getDate("expirationDate")
                );
                stock.setProductName(rs.getString("productName"));
                list.add(stock);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public Stock getStockByProductID(String productID) {
        String sql = "SELECT s.*, p.name AS productName FROM stock s JOIN products p ON s.productID = p.productID WHERE s.productID = ? LIMIT 1";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, productID);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Stock stock = new Stock(
                        rs.getString("stockID"),
                        rs.getString("productID"),
                        rs.getInt("stqQuantity"),
                        rs.getDouble("price"),
                        rs.getDate("expirationDate")
                );
                stock.setProductName(rs.getString("productName"));
                return stock;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean deductStock(String productID, int quantity) {
        String sql = "UPDATE stock SET stqQuantity = stqQuantity - ? WHERE productID = ? AND stqQuantity >= ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, quantity);
            ps.setString(2, productID);
            ps.setInt(3, quantity);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Stock> getLowStockItems(int threshold) {
        List<Stock> list = new ArrayList<>();
        String sql = "SELECT s.*, p.name AS productName FROM stock s JOIN products p ON s.productID = p.productID WHERE s.stqQuantity <= ? ORDER BY s.stqQuantity";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, threshold);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Stock stock = new Stock(
                        rs.getString("stockID"),
                        rs.getString("productID"),
                        rs.getInt("stqQuantity"),
                        rs.getDouble("price"),
                        rs.getDate("expirationDate")
                );
                stock.setProductName(rs.getString("productName"));
                list.add(stock);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public String generateNextStockID() {
        String sql = "SELECT stockID FROM stock ORDER BY stockID DESC LIMIT 1";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            if (rs.next()) {
                String last = rs.getString("stockID");
                int num = Integer.parseInt(last.replaceAll("[^0-9]", "")) + 1;
                return String.format("STK%03d", num);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "STK001";
    }
}
