package com.pharmatrack.model;

import java.sql.Date;

public class Stock {
    private String stockID;
    private String productID;
    private String productName;
    private int stqQuantity;
    private double price;
    private Date expirationDate;

    public Stock() {}

    public Stock(String stockID, String productID, int stqQuantity, double price, Date expirationDate) {
        this.stockID = stockID;
        this.productID = productID;
        this.stqQuantity = stqQuantity;
        this.price = price;
        this.expirationDate = expirationDate;
    }

    public String getStockID() { return stockID; }
    public void setStockID(String stockID) { this.stockID = stockID; }

    public String getProductID() { return productID; }
    public void setProductID(String productID) { this.productID = productID; }

    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }

    public int getStqQuantity() { return stqQuantity; }
    public void setStqQuantity(int stqQuantity) { this.stqQuantity = stqQuantity; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public Date getExpirationDate() { return expirationDate; }
    public void setExpirationDate(Date expirationDate) { this.expirationDate = expirationDate; }
}
