package com.pharmatrack.model;

import java.sql.Date;

public class Transaction {
    private String transactionID;
    private String productID;
    private String productName;
    private Date date;
    private int quantity;
    private double totalPrice;
    private String paymentType;
    private String userID;

    public Transaction() {}

    public Transaction(String transactionID, String productID, Date date,
                       int quantity, double totalPrice, String paymentType, String userID) {
        this.transactionID = transactionID;
        this.productID = productID;
        this.date = date;
        this.quantity = quantity;
        this.totalPrice = totalPrice;
        this.paymentType = paymentType;
        this.userID = userID;
    }

    public String getTransactionID() { return transactionID; }
    public void setTransactionID(String transactionID) { this.transactionID = transactionID; }

    public String getProductID() { return productID; }
    public void setProductID(String productID) { this.productID = productID; }

    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }

    public Date getDate() { return date; }
    public void setDate(Date date) { this.date = date; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public double getTotalPrice() { return totalPrice; }
    public void setTotalPrice(double totalPrice) { this.totalPrice = totalPrice; }

    public String getPaymentType() { return paymentType; }
    public void setPaymentType(String paymentType) { this.paymentType = paymentType; }

    public String getUserID() { return userID; }
    public void setUserID(String userID) { this.userID = userID; }
}
