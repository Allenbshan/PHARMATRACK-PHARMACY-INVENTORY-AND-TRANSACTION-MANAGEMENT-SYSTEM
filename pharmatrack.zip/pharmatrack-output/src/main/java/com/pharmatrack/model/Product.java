package com.pharmatrack.model;

import java.sql.Date;

public class Product {
    private String productID;
    private String name;
    private String description;
    private Date expirationDate;

    public Product() {}

    public Product(String productID, String name, String description, Date expirationDate) {
        this.productID = productID;
        this.name = name;
        this.description = description;
        this.expirationDate = expirationDate;
    }

    public String getProductID() { return productID; }
    public void setProductID(String productID) { this.productID = productID; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public Date getExpirationDate() { return expirationDate; }
    public void setExpirationDate(Date expirationDate) { this.expirationDate = expirationDate; }

    @Override
    public String toString() {
        return productID + " - " + name;
    }
}
