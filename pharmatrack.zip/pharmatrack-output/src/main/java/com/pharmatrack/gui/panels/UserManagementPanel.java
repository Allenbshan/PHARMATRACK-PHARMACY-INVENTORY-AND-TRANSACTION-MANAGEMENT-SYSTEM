package com.pharmatrack.gui.panels;

import com.pharmatrack.dao.UserDAO;
import com.pharmatrack.gui.UITheme;
import com.pharmatrack.model.User;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class UserManagementPanel extends JPanel {

    private JTextField userIDField, usernameField;
    private JPasswordField passwordField;
    private JComboBox<String> roleCombo;
    private JTable table;
    private DefaultTableModel tableModel;
    private UserDAO userDAO = new UserDAO();
    private String selectedUserID = null;

    public UserManagementPanel() {
        setLayout(new BorderLayout(10, 10));
        setBackground(UITheme.LIGHT_GRAY);
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBackground(UITheme.WHITE);
        formPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.BORDER),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        formPanel.setPreferredSize(new Dimension(200, 0));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(4, 0, 4, 0);
        gbc.gridx = 0;

        gbc.gridy = 0;
        formPanel.add(UITheme.createLabel("User ID"), gbc);
        userIDField = UITheme.createTextField();
        gbc.gridy = 1;
        formPanel.add(userIDField, gbc);

        gbc.gridy = 2;
        formPanel.add(UITheme.createLabel("Username"), gbc);
        usernameField = UITheme.createTextField();
        gbc.gridy = 3;
        formPanel.add(usernameField, gbc);

        gbc.gridy = 4;
        formPanel.add(UITheme.createLabel("Password"), gbc);
        passwordField = new JPasswordField();
        passwordField.setFont(UITheme.FONT_LABEL);
        gbc.gridy = 5;
        formPanel.add(passwordField, gbc);

        gbc.gridy = 6;
        formPanel.add(UITheme.createLabel("Role"), gbc);
        roleCombo = new JComboBox<>(new String[]{"Admin", "User"});
        roleCombo.setFont(UITheme.FONT_LABEL);
        gbc.gridy = 7;
        formPanel.add(roleCombo, gbc);

        gbc.gridy = 8; gbc.weighty = 1.0;
        formPanel.add(Box.createVerticalGlue(), gbc);
        gbc.weighty = 0;

        JButton addBtn = UITheme.createButton("Add User", UITheme.BTN_ADD);
        gbc.gridy = 9; gbc.insets = new Insets(6, 0, 3, 0);
        formPanel.add(addBtn, gbc);

        JButton updateBtn = UITheme.createButton("Update User", UITheme.BTN_UPDATE);
        gbc.gridy = 10; gbc.insets = new Insets(3, 0, 3, 0);
        formPanel.add(updateBtn, gbc);

        JButton deleteBtn = UITheme.createButton("Delete User", UITheme.BTN_DELETE);
        gbc.gridy = 11;
        formPanel.add(deleteBtn, gbc);

        String[] columns = {"User ID", "Username", "Role"};
        tableModel = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        UITheme.styleTable(table);

        table.getSelectionModel().addListSelectionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                selectedUserID = (String) tableModel.getValueAt(row, 0);
                userIDField.setText(selectedUserID);
                usernameField.setText((String) tableModel.getValueAt(row, 1));
                String role = (String) tableModel.getValueAt(row, 2);
                roleCombo.setSelectedItem(role);
                passwordField.setText("");
            }
        });

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(UITheme.BORDER));

        addBtn.addActionListener(e -> addUser());
        updateBtn.addActionListener(e -> updateUser());
        deleteBtn.addActionListener(e -> deleteUser());

        add(formPanel, BorderLayout.WEST);
        add(scrollPane, BorderLayout.CENTER);

        loadData();
    }

    public void loadData() {
        tableModel.setRowCount(0);
        for (User u : userDAO.getAllUsers()) {
            tableModel.addRow(new Object[]{u.getUserID(), u.getUsername(), u.getRole()});
        }
    }

    private void addUser() {
        String userID = userIDField.getText().trim();
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();
        String role = (String) roleCombo.getSelectedItem();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Username and Password are required.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String newID = userID.isEmpty() ? userDAO.generateNextUserID() : userID;

        if (userDAO.usernameExists(username)) {
            JOptionPane.showMessageDialog(this, "Username already exists.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }

        User user = new User(newID, username, password, role);
        if (userDAO.addUser(user)) {
            JOptionPane.showMessageDialog(this, "User added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            clearFields();
            loadData();
        } else {
            JOptionPane.showMessageDialog(this, "Failed to add user.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateUser() {
        if (selectedUserID == null) {
            JOptionPane.showMessageDialog(this, "Please select a user to update.", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();
        String role = (String) roleCombo.getSelectedItem();

        if (username.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Username is required.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this, "Update this user's information?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        User user = new User(selectedUserID, username, password.isEmpty() ? null : password, role);
        if (password.isEmpty()) {
            // Only update username and role
            String sql_note = "Note: Leave password blank to keep existing password.";
        }
        if (userDAO.updateUser(user)) {
            JOptionPane.showMessageDialog(this, "User updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            clearFields();
            loadData();
        } else {
            JOptionPane.showMessageDialog(this, "Failed to update user.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteUser() {
        if (selectedUserID == null) {
            JOptionPane.showMessageDialog(this, "Please select a user to delete.", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this,
                "Delete user: " + usernameField.getText() + "?\nThis action cannot be undone.",
                "Confirm Delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (confirm != JOptionPane.YES_OPTION) return;

        if (userDAO.deleteUser(selectedUserID)) {
            JOptionPane.showMessageDialog(this, "User deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            clearFields();
            loadData();
        } else {
            JOptionPane.showMessageDialog(this, "Failed to delete user.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        userIDField.setText("");
        usernameField.setText("");
        passwordField.setText("");
        roleCombo.setSelectedIndex(0);
        selectedUserID = null;
        table.clearSelection();
    }
}
