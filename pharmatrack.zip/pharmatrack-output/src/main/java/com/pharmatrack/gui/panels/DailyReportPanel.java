package com.pharmatrack.gui.panels;

import com.pharmatrack.dao.StockDAO;
import com.pharmatrack.dao.TransactionDAO;
import com.pharmatrack.gui.UITheme;
import com.pharmatrack.model.Stock;
import com.pharmatrack.model.Transaction;

import javax.swing.*;
import java.awt.*;
import java.sql.Date;
import java.util.List;

public class DailyReportPanel extends JPanel {

    private JSpinner yearSpinner, daySpinner;
    private JComboBox<String> monthCombo;
    private JTextArea reportArea;
    private TransactionDAO transactionDAO = new TransactionDAO();
    private StockDAO stockDAO = new StockDAO();

    private static final String[] MONTHS = {
            "01-January", "02-February", "03-March", "04-April",
            "05-May", "06-June", "07-July", "08-August",
            "09-September", "10-October", "11-November", "12-December"
    };

    public DailyReportPanel() {
        setLayout(new BorderLayout(10, 10));
        setBackground(UITheme.LIGHT_GRAY);
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Top bar
        JPanel topBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        topBar.setBackground(UITheme.WHITE);
        topBar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.BORDER),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));

        topBar.add(new JLabel("Year:"));
        yearSpinner = new JSpinner(new SpinnerNumberModel(2026, 2000, 2100, 1));
        yearSpinner.setPreferredSize(new Dimension(70, 26));
        yearSpinner.setFont(UITheme.FONT_LABEL);
        topBar.add(yearSpinner);

        topBar.add(new JLabel("Month:"));
        monthCombo = new JComboBox<>(MONTHS);
        monthCombo.setFont(UITheme.FONT_LABEL);
        monthCombo.setPreferredSize(new Dimension(120, 26));
        topBar.add(monthCombo);

        topBar.add(new JLabel("Day:"));
        daySpinner = new JSpinner(new SpinnerNumberModel(1, 1, 31, 1));
        daySpinner.setPreferredSize(new Dimension(60, 26));
        daySpinner.setFont(UITheme.FONT_LABEL);
        topBar.add(daySpinner);

        JButton salesBtn = UITheme.createButton("Sales Report", UITheme.BTN_ADD);
        salesBtn.setPreferredSize(new Dimension(110, 30));
        JButton stockBtn = UITheme.createButton("Stock Report", new Color(0, 150, 136));
        stockBtn.setPreferredSize(new Dimension(110, 30));

        topBar.add(salesBtn);
        topBar.add(stockBtn);

        // Report display area
        reportArea = new JTextArea();
        reportArea.setFont(new Font("Courier New", Font.PLAIN, 12));
        reportArea.setEditable(false);
        reportArea.setBackground(UITheme.WHITE);
        reportArea.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
        reportArea.setLineWrap(true);
        reportArea.setWrapStyleWord(true);

        JScrollPane scrollPane = new JScrollPane(reportArea);
        scrollPane.setBorder(BorderFactory.createLineBorder(UITheme.BORDER));

        // Panel inside scroll to show a card
        JPanel reportCard = new JPanel(new BorderLayout());
        reportCard.setBackground(UITheme.WHITE);
        reportCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.BORDER),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        reportCard.add(scrollPane, BorderLayout.CENTER);

        salesBtn.addActionListener(e -> generateSalesReport());
        stockBtn.addActionListener(e -> generateStockReport());

        // Initial daily summary
        generateDailyReport();

        add(topBar, BorderLayout.NORTH);
        add(reportCard, BorderLayout.CENTER);
    }

    private Date getSelectedDate() {
        int year = (int) yearSpinner.getValue();
        int day = (int) daySpinner.getValue();
        String monthStr = (String) monthCombo.getSelectedItem();
        int month = Integer.parseInt(monthStr.substring(0, 2));
        try {
            return Date.valueOf(String.format("%04d-%02d-%02d", year, month, day));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Invalid date selected.", "Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }

    private void generateDailyReport() {
        Date date = getSelectedDate();
        if (date == null) return;

        double totalSales = transactionDAO.getTotalSalesByDate(date);
        int totalTxns = transactionDAO.getTotalTransactionsByDate(date);
        List<Stock> lowStock = stockDAO.getLowStockItems(10);

        StringBuilder sb = new StringBuilder();
        sb.append("PHARMATRACK DAILY REPORT - ").append(date).append("\n");
        sb.append("─".repeat(50)).append("\n\n");
        sb.append("──── SALES REPORT ────\n");
        sb.append(String.format("Total Transactions: %d%n", totalTxns));
        sb.append(String.format("Total Sales: PHP %.2f%n", totalSales));
        sb.append("\n──── STOCK REPORT ────\n");
        sb.append(String.format("Low Stock Count: %d%n", lowStock.size()));
        sb.append("Low Stock Items:\n");
        if (lowStock.isEmpty()) {
            sb.append("  No low-stock items.\n");
        } else {
            for (Stock s : lowStock) {
                sb.append(String.format("  • %s (%s) — Qty: %d%n",
                        s.getProductName(), s.getProductID(), s.getStqQuantity()));
            }
        }
        reportArea.setText(sb.toString());
    }

    private void generateSalesReport() {
        Date date = getSelectedDate();
        if (date == null) return;

        double totalSales = transactionDAO.getTotalSalesByDate(date);
        int totalTxns = transactionDAO.getTotalTransactionsByDate(date);
        List<Transaction> txns = transactionDAO.getTransactionsByDate(date);

        StringBuilder sb = new StringBuilder();
        sb.append("╔══════════════════════════════╗\n");
        sb.append("║         SALES REPORT         ║\n");
        sb.append("╚══════════════════════════════╝\n\n");
        sb.append("Report Date: ").append(date).append("\n");
        sb.append("Date Generated: ").append(date).append("\n");
        sb.append(String.format("Total Transactions: %d%n", totalTxns));
        sb.append(String.format("Total Sales: PHP %.2f%n", totalSales));
        sb.append("\n────────────────────────────────\n");
        sb.append("Transaction Details:\n\n");

        if (txns.isEmpty()) {
            sb.append("  No transactions for this date.\n");
        } else {
            sb.append(String.format("  %-12s %-12s %-6s %-10s %-10s%n",
                    "TXN ID", "PRODUCT", "QTY", "TOTAL", "PAYMENT"));
            sb.append("  ").append("─".repeat(52)).append("\n");
            for (Transaction t : txns) {
                sb.append(String.format("  %-12s %-12s %-6d PHP %-8.2f %-10s%n",
                        t.getTransactionID(), t.getProductID(),
                        t.getQuantity(), t.getTotalPrice(), t.getPaymentType()));
            }
        }
        reportArea.setText(sb.toString());
    }

    private void generateStockReport() {
        Date date = getSelectedDate();
        if (date == null) return;

        List<Stock> lowStock = stockDAO.getLowStockItems(10);
        List<Stock> allStock = stockDAO.getAllStock();

        StringBuilder sb = new StringBuilder();
        sb.append("╔══════════════════════════════╗\n");
        sb.append("║         STOCK REPORT         ║\n");
        sb.append("╚══════════════════════════════╝\n\n");
        sb.append("Report Date: ").append(date).append("\n");
        sb.append("Date Generated: ").append(date).append("\n");
        sb.append("Low Stock Count: ").append(lowStock.size()).append("\n");
        sb.append("Low Stock Items (qty ≤ 10):\n");

        if (lowStock.isEmpty()) {
            sb.append("  All items have sufficient stock.\n");
        } else {
            for (Stock s : lowStock) {
                sb.append(String.format("  • %s (%s) — Qty: %d | Exp: %s%n",
                        s.getProductName(), s.getProductID(),
                        s.getStqQuantity(), s.getExpirationDate()));
            }
        }

        sb.append("\n────────────────────────────────\n");
        sb.append("All Stock Summary:\n\n");
        sb.append(String.format("  %-10s %-20s %-6s %-10s%n", "STOCK ID", "PRODUCT", "QTY", "EXPIRY"));
        sb.append("  ").append("─".repeat(50)).append("\n");
        for (Stock s : allStock) {
            String status = s.getStqQuantity() == 0 ? " ❌ OUT" : (s.getStqQuantity() <= 10 ? " ⚠ LOW" : "");
            sb.append(String.format("  %-10s %-20s %-6d %-10s%s%n",
                    s.getStockID(),
                    s.getProductName() != null ? s.getProductName() : s.getProductID(),
                    s.getStqQuantity(),
                    s.getExpirationDate() != null ? s.getExpirationDate() : "N/A",
                    status));
        }
        reportArea.setText(sb.toString());
    }
}
