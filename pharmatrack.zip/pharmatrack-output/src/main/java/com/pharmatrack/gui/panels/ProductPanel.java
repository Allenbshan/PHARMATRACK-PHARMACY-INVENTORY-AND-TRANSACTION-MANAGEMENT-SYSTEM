package com.pharmatrack.gui.panels;

import com.pharmatrack.dao.ProductDAO;
import com.pharmatrack.gui.UITheme;
import com.pharmatrack.model.Product;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Date;
import java.util.List;

public class ProductPanel extends JPanel {

    private JTextField nameField, descriptionField, expiryField;
    private JTable table;
    private DefaultTableModel tableModel;
    private ProductDAO productDAO = new ProductDAO();
    private boolean isAdmin;
    private String selectedProductID = null;

    public ProductPanel(boolean isAdmin) {
        this.isAdmin = isAdmin;
        setLayout(new BorderLayout(10, 10));
        setBackground(UITheme.LIGHT_GRAY);
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Left form panel
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBackground(UITheme.WHITE);
        formPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.BORDER),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        formPanel.setPreferredSize(new Dimension(200, 0));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(4, 0, 4, 0);
        gbc.gridx = 0;

        gbc.gridy = 0;
        formPanel.add(UITheme.createLabel("Product Name"), gbc);
        nameField = UITheme.createTextField();
        gbc.gridy = 1;
        formPanel.add(nameField, gbc);

        gbc.gridy = 2;
        formPanel.add(UITheme.createLabel("Description"), gbc);
        descriptionField = UITheme.createTextField();
        gbc.gridy = 3;
        formPanel.add(descriptionField, gbc);

        gbc.gridy = 4;
        formPanel.add(UITheme.createLabel("Expiry Date (YYYY-MM-DD)"), gbc);
        expiryField = UITheme.createTextField();
        gbc.gridy = 5;
        formPanel.add(expiryField, gbc);

        // Spacer
        gbc.gridy = 6;
        gbc.weighty = 1.0;
        formPanel.add(Box.createVerticalGlue(), gbc);
        gbc.weighty = 0;

        JButton addBtn = UITheme.createButton("Add Product", UITheme.BTN_ADD);
        gbc.gridy = 7; gbc.insets = new Insets(6, 0, 3, 0);
        formPanel.add(addBtn, gbc);

        JButton updateBtn = UITheme.createButton("Update Product", UITheme.BTN_UPDATE);
        gbc.gridy = 8; gbc.insets = new Insets(3, 0, 3, 0);
        formPanel.add(updateBtn, gbc);

        JButton deleteBtn = UITheme.createButton("Delete Product", UITheme.BTN_DELETE);
        gbc.gridy = 9;
        formPanel.add(deleteBtn, gbc);

        // Table
        String[] columns = {"Product ID", "Name", "Description", "Expiry Date"};
        tableModel = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        UITheme.styleTable(table);

        table.getSelectionModel().addListSelectionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                selectedProductID = (String) tableModel.getValueAt(row, 0);
                nameField.setText((String) tableModel.getValueAt(row, 1));
                descriptionField.setText((String) tableModel.getValueAt(row, 2));
                Object expiry = tableModel.getValueAt(row, 3);
                expiryField.setText(expiry != null ? expiry.toString() : "");
            }
        });

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(UITheme.BORDER));

        // Button actions
        addBtn.addActionListener(e -> addProduct());
        updateBtn.addActionListener(e -> updateProduct());
        deleteBtn.addActionListener(e -> deleteProduct());

        add(formPanel, BorderLayout.WEST);
        add(scrollPane, BorderLayout.CENTER);

        loadData();
    }

    public void loadData() {
        tableModel.setRowCount(0);
        List<Product> products = productDAO.getAllProducts();
        for (Product p : products) {
            tableModel.addRow(new Object[]{
                    p.getProductID(), p.getName(), p.getDescription(), p.getExpirationDate()
            });
        }
    }

    private void addProduct() {
        String name = nameField.getText().trim();
        String desc = descriptionField.getText().trim();
        String expiry = expiryField.getText().trim();

        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Product Name is required.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        Date expiryDate = null;
        if (!expiry.isEmpty()) {
            try {
                expiryDate = Date.valueOf(expiry);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid date format. Use YYYY-MM-DD.", "Validation", JOptionPane.WARNING_MESSAGE);
                return;
            }
        }
        String newID = productDAO.generateNextProductID();
        Product p = new Product(newID, name, desc, expiryDate);
        if (productDAO.addProduct(p)) {
            JOptionPane.showMessageDialog(this, "Product added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            clearFields();
            loadData();
        } else {
            JOptionPane.showMessageDialog(this, "Failed to add product.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateProduct() {
        if (selectedProductID == null) {
            JOptionPane.showMessageDialog(this, "Please select a product to update.", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String name = nameField.getText().trim();
        String desc = descriptionField.getText().trim();
        String expiry = expiryField.getText().trim();
        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Product Name is required.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        Date expiryDate = null;
        if (!expiry.isEmpty()) {
            try { expiryDate = Date.valueOf(expiry); }
            catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid date. Use YYYY-MM-DD.", "Validation", JOptionPane.WARNING_MESSAGE);
                return;
            }
        }
        int confirm = JOptionPane.showConfirmDialog(this, "Update this product?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        Product p = new Product(selectedProductID, name, desc, expiryDate);
        if (productDAO.updateProduct(p)) {
            JOptionPane.showMessageDialog(this, "Product updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            clearFields();
            loadData();
        } else {
            JOptionPane.showMessageDialog(this, "Failed to update product.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteProduct() {
        if (selectedProductID == null) {
            JOptionPane.showMessageDialog(this, "Please select a product to delete.", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete this product?\nThis will also delete related stock records.",
                "Confirm Delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (confirm != JOptionPane.YES_OPTION) return;

        if (productDAO.deleteProduct(selectedProductID)) {
            JOptionPane.showMessageDialog(this, "Product deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            clearFields();
            loadData();
        } else {
            JOptionPane.showMessageDialog(this, "Failed to delete product.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        nameField.setText("");
        descriptionField.setText("");
        expiryField.setText("");
        selectedProductID = null;
        table.clearSelection();
    }
}
