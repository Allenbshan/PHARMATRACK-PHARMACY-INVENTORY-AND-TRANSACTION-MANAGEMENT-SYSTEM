package com.pharmatrack.gui;

import com.pharmatrack.dao.UserDAO;
import com.pharmatrack.model.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.geom.RoundRectangle2D;

public class LoginScreen extends JFrame {

    private JTextField usernameField;
    private JPasswordField passwordField;
    private UserDAO userDAO = new UserDAO();

    public LoginScreen() {
        setTitle("PharmaTrack - Login");
        setSize(860, 560);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        // Two-column split layout
        JPanel root = new JPanel(new GridLayout(1, 2, 0, 0));

        // ── LEFT PANEL (brand / illustration) ──────────────────────────────
        JPanel left = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // Dark green background
                g2.setColor(new Color(18, 78, 46));
                g2.fillRect(0, 0, getWidth(), getHeight());

                // Subtle circle decorations
                g2.setColor(new Color(255, 255, 255, 18));
                g2.fillOval(-60, -60, 220, 220);
                g2.setColor(new Color(255, 255, 255, 10));
                g2.fillOval(getWidth() - 130, getHeight() - 130, 240, 240);
                g2.setColor(new Color(255, 255, 255, 8));
                g2.fillOval(40, getHeight() - 180, 300, 300);
            }
        };
        left.setLayout(new GridBagLayout());

        JPanel brandBox = new JPanel();
        brandBox.setLayout(new BoxLayout(brandBox, BoxLayout.Y_AXIS));
        brandBox.setOpaque(false);

        // Pill logo
        JLabel logoLabel = new JLabel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // Pill shape (rounded rectangle)
                g2.setColor(new Color(255, 255, 255, 230));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), getHeight(), getHeight());
                // Left half tint
                g2.setColor(new Color(100, 220, 150, 180));
                g2.fillRoundRect(0, 0, getWidth() / 2 + 2, getHeight(), getHeight(), getHeight());
                // Divider line
                g2.setColor(new Color(18, 78, 46));
                g2.setStroke(new BasicStroke(2));
                g2.drawLine(getWidth() / 2, 6, getWidth() / 2, getHeight() - 6);
                g2.dispose();
            }
        };
        logoLabel.setPreferredSize(new Dimension(72, 32));
        logoLabel.setMaximumSize(new Dimension(72, 32));
        logoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel appTitle = new JLabel("PharmaTrack");
        appTitle.setFont(new Font("SansSerif", Font.BOLD, 32));
        appTitle.setForeground(Color.WHITE);
        appTitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel appDesc = new JLabel("Pharmacy Management System");
        appDesc.setFont(new Font("SansSerif", Font.PLAIN, 13));
        appDesc.setForeground(new Color(180, 220, 200));
        appDesc.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Feature bullets
        String[] features = { "📦  Inventory Tracking", "💊  Product Management", "📊  Daily Reports" };
        brandBox.add(logoLabel);
        brandBox.add(Box.createVerticalStrut(20));
        brandBox.add(appTitle);
        brandBox.add(Box.createVerticalStrut(6));
        brandBox.add(appDesc);
        brandBox.add(Box.createVerticalStrut(32));
        for (String f : features) {
            JLabel fl = new JLabel(f);
            fl.setFont(new Font("SansSerif", Font.PLAIN, 12));
            fl.setForeground(new Color(180, 230, 205));
            fl.setAlignmentX(Component.CENTER_ALIGNMENT);
            brandBox.add(fl);
            brandBox.add(Box.createVerticalStrut(8));
        }

        left.add(brandBox);

        // ── RIGHT PANEL (form) ──────────────────────────────────────────────
        JPanel right = new JPanel(new GridBagLayout());
        right.setBackground(new Color(250, 251, 252));

        JPanel formBox = new JPanel();
        formBox.setLayout(new BoxLayout(formBox, BoxLayout.Y_AXIS));
        formBox.setOpaque(false);
        formBox.setPreferredSize(new Dimension(310, 380));

        JLabel welcomeBack = new JLabel("Welcome back");
        welcomeBack.setFont(new Font("SansSerif", Font.BOLD, 24));
        welcomeBack.setForeground(new Color(22, 40, 32));
        welcomeBack.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel sub = new JLabel("Sign in to your account");
        sub.setFont(new Font("SansSerif", Font.PLAIN, 13));
        sub.setForeground(new Color(100, 115, 108));
        sub.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Username
        JLabel uLbl = makeFieldLabel("Username");
        uLbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        usernameField = makeField();
        usernameField.setAlignmentX(Component.LEFT_ALIGNMENT);
        usernameField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));

        // Password
        JLabel pLbl = makeFieldLabel("Password");
        pLbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        passwordField = new JPasswordField();
        stylePasswordField(passwordField);
        passwordField.setAlignmentX(Component.LEFT_ALIGNMENT);
        passwordField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));

        // Sign In button
        JButton signInBtn = makeGreenButton("Sign In");
        signInBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        signInBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));

        // Register link
        JButton registerBtn = new JButton("Don't have an account? Create one");
        registerBtn.setFont(new Font("SansSerif", Font.PLAIN, 11));
        registerBtn.setForeground(new Color(34, 139, 87));
        registerBtn.setBackground(null);
        registerBtn.setBorderPainted(false);
        registerBtn.setFocusPainted(false);
        registerBtn.setContentAreaFilled(false);
        registerBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        registerBtn.setAlignmentX(Component.CENTER_ALIGNMENT);

        formBox.add(welcomeBack);
        formBox.add(Box.createVerticalStrut(4));
        formBox.add(sub);
        formBox.add(Box.createVerticalStrut(30));
        formBox.add(uLbl);
        formBox.add(Box.createVerticalStrut(5));
        formBox.add(usernameField);
        formBox.add(Box.createVerticalStrut(16));
        formBox.add(pLbl);
        formBox.add(Box.createVerticalStrut(5));
        formBox.add(passwordField);
        formBox.add(Box.createVerticalStrut(24));
        formBox.add(signInBtn);
        formBox.add(Box.createVerticalStrut(14));
        formBox.add(registerBtn);

        right.add(formBox);

        root.add(left);
        root.add(right);
        setContentPane(root);

        signInBtn.addActionListener((ActionEvent e) -> doLogin());
        passwordField.addActionListener((ActionEvent e) -> doLogin());
        registerBtn.addActionListener(e -> new RegisterScreen(this).setVisible(true));
    }

    private JLabel makeFieldLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("SansSerif", Font.BOLD, 11));
        l.setForeground(new Color(80, 100, 90));
        return l;
    }

    private JTextField makeField() {
        JTextField tf = new JTextField();
        tf.setFont(new Font("SansSerif", Font.PLAIN, 13));
        tf.setBackground(Color.WHITE);
        tf.setForeground(new Color(22, 40, 32));
        tf.setCaretColor(new Color(34, 139, 87));
        tf.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(210, 220, 215), 1),
                BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));
        return tf;
    }

    private void stylePasswordField(JPasswordField pf) {
        pf.setFont(new Font("SansSerif", Font.PLAIN, 13));
        pf.setBackground(Color.WHITE);
        pf.setForeground(new Color(22, 40, 32));
        pf.setCaretColor(new Color(34, 139, 87));
        pf.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(210, 220, 215), 1),
                BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));
    }

    private JButton makeGreenButton(String text) {
        JButton btn = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                FontMetrics fm = g2.getFontMetrics(getFont());
                g2.setColor(Color.WHITE);
                g2.setFont(getFont());
                String t = getText();
                g2.drawString(t, (getWidth() - fm.stringWidth(t)) / 2,
                        (getHeight() + fm.getAscent() - fm.getDescent()) / 2);
                g2.dispose();
            }
        };
        btn.setBackground(new Color(34, 139, 87));
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("SansSerif", Font.BOLD, 13));
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(false);
        btn.setOpaque(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) { btn.setBackground(new Color(26, 110, 68)); }
            public void mouseExited(java.awt.event.MouseEvent e)  { btn.setBackground(new Color(34, 139, 87)); }
        });
        return btn;
    }

    private void doLogin() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();
        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter your username and password.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        User user = userDAO.login(username, password);
        if (user != null) {
            dispose();
            if ("Admin".equals(user.getRole())) new AdminDashboard(user).setVisible(true);
            else new UserDashboard(user).setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this, "Invalid username or password.", "Login Failed", JOptionPane.ERROR_MESSAGE);
            passwordField.setText("");
        }
    }
}
