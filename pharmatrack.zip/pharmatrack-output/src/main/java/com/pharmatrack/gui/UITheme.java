package com.pharmatrack.gui;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;

public class UITheme {

    // Simple, clean color palette
    public static final Color BG = new Color(250, 251, 252);
    public static final Color WHITE = Color.WHITE;
    public static final Color ACCENT = new Color(34, 139, 87);
    public static final Color ACCENT_LIGHT = new Color(220, 242, 230);
    public static final Color DANGER = new Color(220, 53, 69);
    public static final Color MUTED = new Color(108, 117, 125);
    public static final Color BORDER = new Color(222, 226, 230);
    public static final Color TEXT = new Color(33, 37, 41);
    public static final Color TEXT_LIGHT = new Color(108, 117, 125);
    public static final Color TABLE_STRIPE = new Color(248, 249, 250);
    public static final Color TABLE_SELECTED = new Color(220, 242, 230);
    public static final Color TABLE_HEADER_BG = new Color(248, 249, 250);

    // Legacy aliases
    public static final Color PRIMARY_BLUE = ACCENT;
    public static final Color DARK_BLUE = new Color(26, 110, 68);
    public static final Color TEAL = ACCENT;
    public static final Color BG_GRADIENT_START = ACCENT;
    public static final Color BG_GRADIENT_END = new Color(26, 110, 68);
    public static final Color HEADER_BG = WHITE;
    public static final Color LIGHT_GRAY = BG;
    public static final Color BTN_ADD = ACCENT;
    public static final Color BTN_UPDATE = new Color(13, 110, 253);
    public static final Color BTN_DELETE = DANGER;
    public static final Color BTN_LOGOUT = DANGER;
    public static final Color TEXT_DARK = TEXT;
    public static final Color TABLE_HEADER = TABLE_HEADER_BG;

    public static final Font FONT_TITLE = new Font("SansSerif", Font.BOLD, 20);
    public static final Font FONT_SUBTITLE = new Font("SansSerif", Font.PLAIN, 12);
    public static final Font FONT_LABEL = new Font("SansSerif", Font.PLAIN, 12);
    public static final Font FONT_BOLD = new Font("SansSerif", Font.BOLD, 12);
    public static final Font FONT_BUTTON = new Font("SansSerif", Font.BOLD, 11);
    public static final Font FONT_TABLE_HEADER = new Font("SansSerif", Font.BOLD, 11);
    public static final Font FONT_TABLE = new Font("SansSerif", Font.PLAIN, 12);

    public static JButton createButton(String text, Color bgColor) {
        JButton btn = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 6, 6);
                FontMetrics fm = g2.getFontMetrics(getFont());
                g2.setColor(getForeground());
                g2.setFont(getFont());
                String t = getText();
                int tx = (getWidth() - fm.stringWidth(t)) / 2;
                int ty = (getHeight() + fm.getAscent() - fm.getDescent()) / 2;
                g2.drawString(t, tx, ty);
                g2.dispose();
            }
        };
        btn.setBackground(bgColor);
        btn.setForeground(WHITE);
        btn.setFont(FONT_BUTTON);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(false);
        btn.setOpaque(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(140, 32));
        final Color orig = bgColor;
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) { btn.setBackground(orig.darker()); }
            public void mouseExited(java.awt.event.MouseEvent e)  { btn.setBackground(orig); }
        });
        return btn;
    }

    public static JTextField createTextField() {
        JTextField tf = new JTextField();
        tf.setFont(FONT_LABEL);
        tf.setBackground(WHITE);
        tf.setForeground(TEXT);
        tf.setCaretColor(ACCENT);
        tf.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER, 1),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));
        return tf;
    }

    public static JLabel createLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(new Font("SansSerif", Font.BOLD, 11));
        lbl.setForeground(TEXT_LIGHT);
        return lbl;
    }

    public static void styleTable(JTable table) {
        table.setFont(FONT_TABLE);
        table.setRowHeight(30);
        table.setSelectionBackground(TABLE_SELECTED);
        table.setSelectionForeground(TEXT);
        table.setGridColor(new Color(238, 240, 242));
        table.setBackground(WHITE);
        table.setShowHorizontalLines(true);
        table.setShowVerticalLines(false);
        table.setIntercellSpacing(new Dimension(0, 0));
        table.getTableHeader().setFont(FONT_TABLE_HEADER);
        table.getTableHeader().setBackground(TABLE_HEADER_BG);
        table.getTableHeader().setForeground(TEXT_LIGHT);
        table.getTableHeader().setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER));
        table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
    }
}
