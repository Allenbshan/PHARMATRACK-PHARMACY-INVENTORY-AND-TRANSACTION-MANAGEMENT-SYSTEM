package com.pharmatrack.gui.panels;

import com.pharmatrack.dao.ProductDAO;
import com.pharmatrack.dao.StockDAO;
import com.pharmatrack.gui.UITheme;
import com.pharmatrack.model.Product;
import com.pharmatrack.model.Stock;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Date;
import java.util.List;

public class StockPanel extends JPanel {

    private JComboBox<Product> productCombo;
    private JTextField quantityField, priceField, expiryField;
    private JTable table;
    private DefaultTableModel tableModel;
    private StockDAO stockDAO = new StockDAO();
    private ProductDAO productDAO = new ProductDAO();
    private boolean isAdmin;
    private String selectedStockID = null;

    public StockPanel(boolean isAdmin) {
        this.isAdmin = isAdmin;
        setLayout(new BorderLayout(10, 10));
        setBackground(UITheme.LIGHT_GRAY);
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Form panel
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBackground(UITheme.WHITE);
        formPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.BORDER),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        formPanel.setPreferredSize(new Dimension(200, 0));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(4, 0, 4, 0);
        gbc.gridx = 0;

        gbc.gridy = 0;
        formPanel.add(UITheme.createLabel("Product"), gbc);
        productCombo = new JComboBox<>();
        productCombo.setFont(UITheme.FONT_LABEL);
        gbc.gridy = 1;
        formPanel.add(productCombo, gbc);

        gbc.gridy = 2;
        formPanel.add(UITheme.createLabel("Quantity"), gbc);
        quantityField = UITheme.createTextField();
        gbc.gridy = 3;
        formPanel.add(quantityField, gbc);

        gbc.gridy = 4;
        formPanel.add(UITheme.createLabel("Price ($)"), gbc);
        priceField = UITheme.createTextField();
        gbc.gridy = 5;
        formPanel.add(priceField, gbc);

        gbc.gridy = 6;
        formPanel.add(UITheme.createLabel("Expiry Date (YYYY-MM-DD)"), gbc);
        expiryField = UITheme.createTextField();
        gbc.gridy = 7;
        formPanel.add(expiryField, gbc);

        gbc.gridy = 8; gbc.weighty = 1.0;
        formPanel.add(Box.createVerticalGlue(), gbc);
        gbc.weighty = 0;

        JButton addBtn = UITheme.createButton("Add Stock", UITheme.BTN_ADD);
        gbc.gridy = 9; gbc.insets = new Insets(6, 0, 3, 0);
        formPanel.add(addBtn, gbc);

        JButton updateBtn = UITheme.createButton("Update Stock", UITheme.BTN_UPDATE);
        gbc.gridy = 10; gbc.insets = new Insets(3, 0, 3, 0);
        formPanel.add(updateBtn, gbc);

        if (isAdmin) {
            JButton deleteBtn = UITheme.createButton("Delete Stock", UITheme.BTN_DELETE);
            gbc.gridy = 11;
            formPanel.add(deleteBtn, gbc);
            deleteBtn.addActionListener(e -> deleteStock());
        }

        // Table
        String[] columns = {"Stock ID", "Product ID", "Product Name", "Quantity", "Price", "Expiry"};
        tableModel = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        UITheme.styleTable(table);

        table.getSelectionModel().addListSelectionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                selectedStockID = (String) tableModel.getValueAt(row, 0);
                String productID = (String) tableModel.getValueAt(row, 1);
                for (int i = 0; i < productCombo.getItemCount(); i++) {
                    if (productCombo.getItemAt(i).getProductID().equals(productID)) {
                        productCombo.setSelectedIndex(i);
                        break;
                    }
                }
                quantityField.setText(String.valueOf(tableModel.getValueAt(row, 3)));
                priceField.setText(String.valueOf(tableModel.getValueAt(row, 4)));
                Object exp = tableModel.getValueAt(row, 5);
                expiryField.setText(exp != null ? exp.toString() : "");
            }
        });

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(UITheme.BORDER));

        addBtn.addActionListener(e -> addStock());
        updateBtn.addActionListener(e -> updateStock());

        add(formPanel, BorderLayout.WEST);
        add(scrollPane, BorderLayout.CENTER);

        loadProducts();
        loadData();
    }

    private void loadProducts() {
        productCombo.removeAllItems();
        for (Product p : productDAO.getAllProducts()) {
            productCombo.addItem(p);
        }
    }

    public void loadData() {
        tableModel.setRowCount(0);
        for (Stock s : stockDAO.getAllStock()) {
            tableModel.addRow(new Object[]{
                    s.getStockID(), s.getProductID(), s.getProductName(),
                    s.getStqQuantity(), s.getPrice(), s.getExpirationDate()
            });
        }
    }

    private void addStock() {
        if (productCombo.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Please select a product.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String qtyStr = quantityField.getText().trim();
        String priceStr = priceField.getText().trim();
        String expiry = expiryField.getText().trim();

        if (qtyStr.isEmpty() || priceStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Quantity and Price are required.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int qty;
        double price;
        try {
            qty = Integer.parseInt(qtyStr);
            price = Double.parseDouble(priceStr);
            if (qty <= 0 || price < 0) throw new NumberFormatException();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid quantity or price.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        Date expiryDate = null;
        if (!expiry.isEmpty()) {
            try { expiryDate = Date.valueOf(expiry); }
            catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid date format. Use YYYY-MM-DD.", "Validation", JOptionPane.WARNING_MESSAGE);
                return;
            }
        }
        Product selectedProduct = (Product) productCombo.getSelectedItem();
        String newID = stockDAO.generateNextStockID();
        Stock stock = new Stock(newID, selectedProduct.getProductID(), qty, price, expiryDate);
        if (stockDAO.addStock(stock)) {
            JOptionPane.showMessageDialog(this, "Stock added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            clearFields();
            loadData();
        } else {
            JOptionPane.showMessageDialog(this, "Failed to add stock.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateStock() {
        if (selectedStockID == null) {
            JOptionPane.showMessageDialog(this, "Please select a stock record to update.", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String qtyStr = quantityField.getText().trim();
        String priceStr = priceField.getText().trim();
        String expiry = expiryField.getText().trim();
        int qty;
        double price;
        try {
            qty = Integer.parseInt(qtyStr);
            price = Double.parseDouble(priceStr);
            if (qty < 0) throw new NumberFormatException();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid quantity or price.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        Date expiryDate = null;
        if (!expiry.isEmpty()) {
            try { expiryDate = Date.valueOf(expiry); }
            catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid date. Use YYYY-MM-DD.", "Validation", JOptionPane.WARNING_MESSAGE);
                return;
            }
        }
        int confirm = JOptionPane.showConfirmDialog(this, "Update this stock record?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        Stock stock = new Stock(selectedStockID, null, qty, price, expiryDate);
        if (stockDAO.updateStock(stock)) {
            JOptionPane.showMessageDialog(this, "Stock updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            clearFields();
            loadData();
        } else {
            JOptionPane.showMessageDialog(this, "Failed to update stock.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteStock() {
        if (selectedStockID == null) {
            JOptionPane.showMessageDialog(this, "Please select a stock record to delete.", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this, "Delete this stock record?", "Confirm Delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (confirm != JOptionPane.YES_OPTION) return;
        if (stockDAO.deleteStock(selectedStockID)) {
            JOptionPane.showMessageDialog(this, "Stock deleted.", "Success", JOptionPane.INFORMATION_MESSAGE);
            clearFields();
            loadData();
        } else {
            JOptionPane.showMessageDialog(this, "Failed to delete stock.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        quantityField.setText("");
        priceField.setText("");
        expiryField.setText("");
        selectedStockID = null;
        table.clearSelection();
    }

    public void refreshProducts() {
        loadProducts();
        loadData();
    }
}
