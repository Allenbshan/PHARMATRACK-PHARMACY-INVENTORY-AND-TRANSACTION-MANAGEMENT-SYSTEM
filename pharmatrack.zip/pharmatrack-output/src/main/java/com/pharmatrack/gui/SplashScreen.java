package com.pharmatrack.gui;

import javax.swing.*;
import java.awt.*;

public class SplashScreen extends JWindow {

    // Exact colors from UITheme / LoginScreen
    private static final Color DARK_GREEN      = new Color(18, 78, 46);
    private static final Color ACCENT_GREEN    = new Color(34, 139, 87);
    private static final Color PILL_WHITE      = new Color(255, 255, 255, 230);
    private static final Color PILL_TINT       = new Color(100, 220, 150, 180);
    private static final Color SUBTITLE_COLOR  = new Color(180, 220, 200);
    private static final Color LOADING_COLOR   = new Color(160, 200, 180);
    private static final Color PROGRESS_BG     = new Color(255, 255, 255, 40);
    private static final Color CIRCLE_1        = new Color(255, 255, 255, 18);
    private static final Color CIRCLE_2        = new Color(255, 255, 255, 10);
    private static final Color CIRCLE_3        = new Color(255, 255, 255, 8);

    public SplashScreen() {
        setSize(480, 320);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

                // Dark green background — matches LoginScreen left panel exactly
                g2.setColor(DARK_GREEN);
                g2.fillRect(0, 0, getWidth(), getHeight());

                // Subtle circle decorations — same as LoginScreen
                g2.setColor(CIRCLE_1);
                g2.fillOval(-60, -60, 220, 220);
                g2.setColor(CIRCLE_2);
                g2.fillOval(getWidth() - 130, getHeight() - 130, 240, 240);
                g2.setColor(CIRCLE_3);
                g2.fillOval(40, getHeight() - 180, 300, 300);
            }
        };
        panel.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.CENTER;

        // Pill logo — identical to LoginScreen
        JLabel pillLogo = new JLabel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(PILL_WHITE);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), getHeight(), getHeight());
                g2.setColor(PILL_TINT);
                g2.fillRoundRect(0, 0, getWidth() / 2 + 2, getHeight(), getHeight(), getHeight());
                g2.setColor(DARK_GREEN);
                g2.setStroke(new BasicStroke(2));
                g2.drawLine(getWidth() / 2, 5, getWidth() / 2, getHeight() - 5);
                g2.dispose();
            }
        };
        pillLogo.setPreferredSize(new Dimension(80, 36));

        // Title
        JLabel titleLabel = new JLabel("PharmaTrack");
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 32));
        titleLabel.setForeground(Color.WHITE);

        // Subtitle
        JLabel subtitleLabel = new JLabel("Pharmacy Management System");
        subtitleLabel.setFont(new Font("SansSerif", Font.PLAIN, 13));
        subtitleLabel.setForeground(SUBTITLE_COLOR);

        // Thin separator
        JPanel sep = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                g.setColor(new Color(255, 255, 255, 30));
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        sep.setPreferredSize(new Dimension(260, 1));
        sep.setOpaque(false);

        // Progress bar — accent green, custom painted
        JProgressBar progressBar = new JProgressBar(0, 100) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int h = getHeight();
                int w = getWidth();
                g2.setColor(PROGRESS_BG);
                g2.fillRoundRect(0, 0, w, h, h, h);
                int fillW = (int) (w * (getValue() / (double) getMaximum()));
                if (fillW > 0) {
                    g2.setColor(ACCENT_GREEN);
                    g2.fillRoundRect(0, 0, fillW, h, h, h);
                }
                g2.dispose();
            }
        };
        progressBar.setPreferredSize(new Dimension(260, 5));
        progressBar.setStringPainted(false);
        progressBar.setBorderPainted(false);
        progressBar.setOpaque(false);

        // Loading label
        JLabel loadingLabel = new JLabel("Loading...");
        loadingLabel.setFont(new Font("SansSerif", Font.PLAIN, 11));
        loadingLabel.setForeground(LOADING_COLOR);

        // Layout
        gbc.gridy = 0; gbc.insets = new Insets(0, 0, 18, 0);  panel.add(pillLogo, gbc);
        gbc.gridy = 1; gbc.insets = new Insets(0, 0, 6, 0);   panel.add(titleLabel, gbc);
        gbc.gridy = 2; gbc.insets = new Insets(0, 0, 20, 0);  panel.add(subtitleLabel, gbc);
        gbc.gridy = 3; gbc.insets = new Insets(0, 0, 8, 0);   panel.add(sep, gbc);
        gbc.gridy = 4; gbc.insets = new Insets(0, 0, 6, 0);   panel.add(progressBar, gbc);
        gbc.gridy = 5; gbc.insets = new Insets(0, 0, 0, 0);   panel.add(loadingLabel, gbc);

        setContentPane(panel);

        // Animated loading messages
        String[] messages = {
            "Loading...", "Connecting to database...",
            "Preparing inventory...", "Almost ready..."
        };

        Timer timer = new Timer(30, null);
        timer.addActionListener(e -> {
            int val = progressBar.getValue();
            if (val < 100) {
                progressBar.setValue(val + 2);
                if      (val == 0)  loadingLabel.setText(messages[0]);
                else if (val == 30) loadingLabel.setText(messages[1]);
                else if (val == 60) loadingLabel.setText(messages[2]);
                else if (val == 85) loadingLabel.setText(messages[3]);
            } else {
                timer.stop();
                setVisible(false);
                dispose();
                new LoginScreen().setVisible(true);
            }
        });

        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent e) {
                timer.stop();
                setVisible(false);
                dispose();
                new LoginScreen().setVisible(true);
            }
        });

        timer.start();
    }
}
