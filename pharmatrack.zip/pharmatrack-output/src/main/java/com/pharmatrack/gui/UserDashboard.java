package com.pharmatrack.gui;

import com.pharmatrack.gui.panels.*;
import com.pharmatrack.model.User;

import javax.swing.*;
import java.awt.*;

public class UserDashboard extends JFrame {

    private User currentUser;

    public UserDashboard(User user) {
        this.currentUser = user;
        setTitle("PharmaTrack");
        setSize(1100, 680);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setMinimumSize(new Dimension(860, 560));
        getContentPane().setBackground(new Color(247, 249, 248));
        setLayout(new BorderLayout());

        add(createHeader(user), BorderLayout.NORTH);

        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(new Font("SansSerif", Font.PLAIN, 12));
        tabs.setBackground(new Color(247, 249, 248));
        tabs.setBorder(BorderFactory.createEmptyBorder(6, 8, 0, 8));

        tabs.addTab("  Products  ", new ProductPanel(false));
        tabs.addTab("  Stock  ", new StockPanel(false));
        tabs.addTab("  Transactions  ", new TransactionPanel(false, user.getUserID()));

        add(tabs, BorderLayout.CENTER);
    }

    private JPanel createHeader(User user) {
        JPanel header = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setColor(new Color(18, 78, 46));
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        header.setPreferredSize(new Dimension(0, 54));
        header.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 20));

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        left.setOpaque(false);

        JLabel pill = new JLabel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(255, 255, 255, 220));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), getHeight(), getHeight());
                g2.setColor(new Color(100, 220, 150, 180));
                g2.fillRoundRect(0, 0, getWidth() / 2 + 1, getHeight(), getHeight(), getHeight());
                g2.setColor(new Color(18, 78, 46));
                g2.setStroke(new BasicStroke(1.5f));
                g2.drawLine(getWidth() / 2, 4, getWidth() / 2, getHeight() - 4);
                g2.dispose();
            }
        };
        pill.setPreferredSize(new Dimension(36, 16));

        JLabel name = new JLabel("PharmaTrack");
        name.setFont(new Font("SansSerif", Font.BOLD, 16));
        name.setForeground(Color.WHITE);

        left.add(pill);
        left.add(name);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        right.setOpaque(false);

        JLabel userInfo = new JLabel(user.getUsername() + "  ·  " + user.getRole());
        userInfo.setFont(new Font("SansSerif", Font.PLAIN, 12));
        userInfo.setForeground(new Color(180, 220, 200));

        JButton logoutBtn = new JButton("Logout") {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(255, 255, 255, 25));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 6, 6);
                g2.setColor(new Color(255, 255, 255, 80));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 6, 6);
                FontMetrics fm = g2.getFontMetrics(getFont());
                g2.setColor(Color.WHITE);
                g2.setFont(getFont());
                String t = getText();
                g2.drawString(t, (getWidth() - fm.stringWidth(t)) / 2,
                        (getHeight() + fm.getAscent() - fm.getDescent()) / 2);
                g2.dispose();
            }
        };
        logoutBtn.setFont(new Font("SansSerif", Font.BOLD, 11));
        logoutBtn.setFocusPainted(false);
        logoutBtn.setBorderPainted(false);
        logoutBtn.setContentAreaFilled(false);
        logoutBtn.setPreferredSize(new Dimension(80, 30));
        logoutBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        logoutBtn.addActionListener(e -> {
            int c = JOptionPane.showConfirmDialog(this, "Logout?", "Confirm", JOptionPane.YES_NO_OPTION);
            if (c == JOptionPane.YES_OPTION) { dispose(); new LoginScreen().setVisible(true); }
        });

        right.add(userInfo);
        right.add(logoutBtn);
        header.add(left, BorderLayout.WEST);
        header.add(right, BorderLayout.EAST);
        return header;
    }
}
