package com.pharmatrack.gui.panels;

import com.pharmatrack.dao.ProductDAO;
import com.pharmatrack.dao.StockDAO;
import com.pharmatrack.dao.TransactionDAO;
import com.pharmatrack.gui.UITheme;
import com.pharmatrack.model.Product;
import com.pharmatrack.model.Stock;
import com.pharmatrack.model.Transaction;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

public class TransactionPanel extends JPanel {

    private JComboBox<Product> productCombo;
    private JTextField quantityField, paymentField;
    private JTable table;
    private DefaultTableModel tableModel;
    private TransactionDAO transactionDAO = new TransactionDAO();
    private StockDAO stockDAO = new StockDAO();
    private ProductDAO productDAO = new ProductDAO();
    private boolean isAdmin;
    private String userID;
    private String selectedTxnID = null;

    public TransactionPanel(boolean isAdmin, String userID) {
        this.isAdmin = isAdmin;
        this.userID = userID;
        setLayout(new BorderLayout(10, 10));
        setBackground(UITheme.LIGHT_GRAY);
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBackground(UITheme.WHITE);
        formPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.BORDER),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        formPanel.setPreferredSize(new Dimension(200, 0));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(4, 0, 4, 0);
        gbc.gridx = 0;

        gbc.gridy = 0;
        formPanel.add(UITheme.createLabel("Product"), gbc);
        productCombo = new JComboBox<>();
        productCombo.setFont(UITheme.FONT_LABEL);
        gbc.gridy = 1;
        formPanel.add(productCombo, gbc);

        gbc.gridy = 2;
        formPanel.add(UITheme.createLabel("Quantity"), gbc);
        quantityField = UITheme.createTextField();
        gbc.gridy = 3;
        formPanel.add(quantityField, gbc);

        gbc.gridy = 4;
        formPanel.add(UITheme.createLabel("Payment Type"), gbc);
        JComboBox<String> paymentCombo = new JComboBox<>(new String[]{"Cash", "Card", "GCash", "Maya"});
        paymentCombo.setFont(UITheme.FONT_LABEL);
        gbc.gridy = 5;
        formPanel.add(paymentCombo, gbc);

        gbc.gridy = 6; gbc.weighty = 1.0;
        formPanel.add(Box.createVerticalGlue(), gbc);
        gbc.weighty = 0;

        JButton createBtn = UITheme.createButton("Create Transaction", UITheme.BTN_ADD);
        gbc.gridy = 7; gbc.insets = new Insets(6, 0, 3, 0);
        formPanel.add(createBtn, gbc);

        if (isAdmin) {
            JButton updateBtn = UITheme.createButton("Update Transaction", UITheme.BTN_UPDATE);
            gbc.gridy = 8; gbc.insets = new Insets(3, 0, 3, 0);
            formPanel.add(updateBtn, gbc);

            updateBtn.addActionListener(e -> updateTransaction((String) paymentCombo.getSelectedItem()));
        }

        // Table
        String[] columns = {"Txn ID", "Product ID", "Date", "Quantity", "Total", "Payment", "User"};
        tableModel = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        UITheme.styleTable(table);

        table.getSelectionModel().addListSelectionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                selectedTxnID = (String) tableModel.getValueAt(row, 0);
                String productID = (String) tableModel.getValueAt(row, 1);
                for (int i = 0; i < productCombo.getItemCount(); i++) {
                    if (productCombo.getItemAt(i).getProductID().equals(productID)) {
                        productCombo.setSelectedIndex(i);
                        break;
                    }
                }
                quantityField.setText(String.valueOf(tableModel.getValueAt(row, 3)));
                String payment = (String) tableModel.getValueAt(row, 5);
                for (int i = 0; i < paymentCombo.getItemCount(); i++) {
                    if (paymentCombo.getItemAt(i).equals(payment)) {
                        paymentCombo.setSelectedIndex(i);
                        break;
                    }
                }
            }
        });

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(UITheme.BORDER));

        createBtn.addActionListener(e -> createTransaction((String) paymentCombo.getSelectedItem()));

        add(formPanel, BorderLayout.WEST);
        add(scrollPane, BorderLayout.CENTER);

        loadProducts();
        loadData();
    }

    private void loadProducts() {
        productCombo.removeAllItems();
        for (Product p : productDAO.getAllProducts()) {
            productCombo.addItem(p);
        }
    }

    public void loadData() {
        tableModel.setRowCount(0);
        for (Transaction t : transactionDAO.getAllTransactions()) {
            tableModel.addRow(new Object[]{
                    t.getTransactionID(), t.getProductID(), t.getDate(),
                    t.getQuantity(), String.format("%.2f", t.getTotalPrice()),
                    t.getPaymentType(), t.getUserID()
            });
        }
    }

    private void createTransaction(String paymentType) {
        if (productCombo.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Please select a product.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String qtyStr = quantityField.getText().trim();
        if (qtyStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Quantity is required.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int qty;
        try {
            qty = Integer.parseInt(qtyStr);
            if (qty <= 0) throw new NumberFormatException();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Quantity must be a positive number.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Product selectedProduct = (Product) productCombo.getSelectedItem();
        Stock stock = stockDAO.getStockByProductID(selectedProduct.getProductID());

        if (stock == null || stock.getStqQuantity() == 0) {
            JOptionPane.showMessageDialog(this, "Product is out of stock!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (stock.getStqQuantity() < qty) {
            JOptionPane.showMessageDialog(this,
                    "Insufficient stock! Available: " + stock.getStqQuantity(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        double total = qty * stock.getPrice();
        int confirm = JOptionPane.showConfirmDialog(this,
                String.format("Process sale?\nProduct: %s\nQuantity: %d\nTotal: PHP %.2f\nPayment: %s",
                        selectedProduct.getName(), qty, total, paymentType),
                "Confirm Transaction", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        String newID = transactionDAO.generateNextTransactionID();
        Transaction txn = new Transaction(newID, selectedProduct.getProductID(),
                Date.valueOf(LocalDate.now()), qty, total, paymentType, userID);

        if (transactionDAO.createTransaction(txn)) {
            stockDAO.deductStock(selectedProduct.getProductID(), qty);
            if (stock.getStqQuantity() - qty <= 10) {
                JOptionPane.showMessageDialog(this,
                        "Transaction recorded!\n⚠ Low stock warning: " + selectedProduct.getName(),
                        "Success - Low Stock Alert", JOptionPane.WARNING_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Transaction created successfully!\nReceipt generated.", "Success", JOptionPane.INFORMATION_MESSAGE);
            }
            clearFields();
            loadData();
        } else {
            JOptionPane.showMessageDialog(this, "Failed to create transaction.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateTransaction(String paymentType) {
        if (selectedTxnID == null) {
            JOptionPane.showMessageDialog(this, "Please select a transaction to update.", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (productCombo.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Please select a product.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String qtyStr = quantityField.getText().trim();
        int qty;
        try {
            qty = Integer.parseInt(qtyStr);
            if (qty <= 0) throw new NumberFormatException();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid quantity.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        Product selectedProduct = (Product) productCombo.getSelectedItem();
        Stock stock = stockDAO.getStockByProductID(selectedProduct.getProductID());
        if (stock == null) {
            JOptionPane.showMessageDialog(this, "Stock not found.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        double total = qty * stock.getPrice();
        int confirm = JOptionPane.showConfirmDialog(this, "Update this transaction?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        Transaction txn = new Transaction(selectedTxnID, selectedProduct.getProductID(),
                Date.valueOf(LocalDate.now()), qty, total, paymentType, userID);
        if (transactionDAO.updateTransaction(txn)) {
            JOptionPane.showMessageDialog(this, "Transaction updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            clearFields();
            loadData();
        } else {
            JOptionPane.showMessageDialog(this, "Failed to update transaction.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        quantityField.setText("");
        selectedTxnID = null;
        table.clearSelection();
    }
}
