package com.pharmatrack.gui;

import com.pharmatrack.dao.UserDAO;
import com.pharmatrack.model.User;

import javax.swing.*;
import java.awt.*;

public class RegisterScreen extends JFrame {

    private JTextField usernameField;
    private JPasswordField passwordField;
    private JComboBox<String> roleCombo;
    private UserDAO userDAO = new UserDAO();
    private JFrame parent;

    public RegisterScreen(JFrame parent) {
        this.parent = parent;
        setTitle("PharmaTrack - Register");
        setSize(860, 560);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel root = new JPanel(new GridLayout(1, 2, 0, 0));

        // Left brand panel
        JPanel left = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(18, 78, 46));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.setColor(new Color(255, 255, 255, 18));
                g2.fillOval(-60, -60, 220, 220);
                g2.setColor(new Color(255, 255, 255, 10));
                g2.fillOval(getWidth() - 130, getHeight() - 130, 240, 240);
            }
        };
        left.setLayout(new GridBagLayout());

        JPanel brandBox = new JPanel();
        brandBox.setLayout(new BoxLayout(brandBox, BoxLayout.Y_AXIS));
        brandBox.setOpaque(false);

        JLabel pillLogo = new JLabel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(255, 255, 255, 230));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), getHeight(), getHeight());
                g2.setColor(new Color(100, 220, 150, 180));
                g2.fillRoundRect(0, 0, getWidth() / 2 + 2, getHeight(), getHeight(), getHeight());
                g2.setColor(new Color(18, 78, 46));
                g2.setStroke(new BasicStroke(2));
                g2.drawLine(getWidth() / 2, 6, getWidth() / 2, getHeight() - 6);
                g2.dispose();
            }
        };
        pillLogo.setPreferredSize(new Dimension(72, 32));
        pillLogo.setMaximumSize(new Dimension(72, 32));
        pillLogo.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel appTitle = new JLabel("PharmaTrack");
        appTitle.setFont(new Font("SansSerif", Font.BOLD, 32));
        appTitle.setForeground(Color.WHITE);
        appTitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel appDesc = new JLabel("Create a new account");
        appDesc.setFont(new Font("SansSerif", Font.PLAIN, 13));
        appDesc.setForeground(new Color(180, 220, 200));
        appDesc.setAlignmentX(Component.CENTER_ALIGNMENT);

        brandBox.add(pillLogo);
        brandBox.add(Box.createVerticalStrut(20));
        brandBox.add(appTitle);
        brandBox.add(Box.createVerticalStrut(6));
        brandBox.add(appDesc);

        left.add(brandBox);

        // Right form panel
        JPanel right = new JPanel(new GridBagLayout());
        right.setBackground(new Color(250, 251, 252));

        JPanel formBox = new JPanel();
        formBox.setLayout(new BoxLayout(formBox, BoxLayout.Y_AXIS));
        formBox.setOpaque(false);
        formBox.setPreferredSize(new Dimension(310, 400));

        JLabel title = new JLabel("Create Account");
        title.setFont(new Font("SansSerif", Font.BOLD, 24));
        title.setForeground(new Color(22, 40, 32));
        title.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel sub = new JLabel("Fill in the details below");
        sub.setFont(new Font("SansSerif", Font.PLAIN, 13));
        sub.setForeground(new Color(100, 115, 108));
        sub.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel uLbl = makeLabel("Username");
        uLbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        usernameField = makeField();
        usernameField.setAlignmentX(Component.LEFT_ALIGNMENT);
        usernameField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));

        JLabel pLbl = makeLabel("Password");
        pLbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        passwordField = new JPasswordField();
        styleField(passwordField);
        passwordField.setAlignmentX(Component.LEFT_ALIGNMENT);
        passwordField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));

        JLabel rLbl = makeLabel("Role");
        rLbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        roleCombo = new JComboBox<>(new String[]{"Admin", "User"});
        roleCombo.setFont(new Font("SansSerif", Font.PLAIN, 13));
        roleCombo.setBackground(Color.WHITE);
        roleCombo.setAlignmentX(Component.LEFT_ALIGNMENT);
        roleCombo.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));

        JButton regBtn = makeGreenButton("Create Account");
        regBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        regBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));

        JButton backBtn = new JButton("Already have an account? Sign in");
        backBtn.setFont(new Font("SansSerif", Font.PLAIN, 11));
        backBtn.setForeground(new Color(34, 139, 87));
        backBtn.setBackground(null);
        backBtn.setBorderPainted(false);
        backBtn.setFocusPainted(false);
        backBtn.setContentAreaFilled(false);
        backBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        backBtn.setAlignmentX(Component.CENTER_ALIGNMENT);

        formBox.add(title);
        formBox.add(Box.createVerticalStrut(4));
        formBox.add(sub);
        formBox.add(Box.createVerticalStrut(26));
        formBox.add(uLbl);
        formBox.add(Box.createVerticalStrut(5));
        formBox.add(usernameField);
        formBox.add(Box.createVerticalStrut(14));
        formBox.add(pLbl);
        formBox.add(Box.createVerticalStrut(5));
        formBox.add(passwordField);
        formBox.add(Box.createVerticalStrut(14));
        formBox.add(rLbl);
        formBox.add(Box.createVerticalStrut(5));
        formBox.add(roleCombo);
        formBox.add(Box.createVerticalStrut(22));
        formBox.add(regBtn);
        formBox.add(Box.createVerticalStrut(12));
        formBox.add(backBtn);

        right.add(formBox);
        root.add(left);
        root.add(right);
        setContentPane(root);

        regBtn.addActionListener(e -> doRegister());
        backBtn.addActionListener(e -> { dispose(); parent.setVisible(true); });
    }

    private JLabel makeLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("SansSerif", Font.BOLD, 11));
        l.setForeground(new Color(80, 100, 90));
        return l;
    }

    private JTextField makeField() {
        JTextField tf = new JTextField();
        tf.setFont(new Font("SansSerif", Font.PLAIN, 13));
        tf.setBackground(Color.WHITE);
        tf.setForeground(new Color(22, 40, 32));
        tf.setCaretColor(new Color(34, 139, 87));
        tf.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(210, 220, 215), 1),
                BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));
        return tf;
    }

    private void styleField(JComponent f) {
        f.setFont(new Font("SansSerif", Font.PLAIN, 13));
        f.setBackground(Color.WHITE);
        f.setForeground(new Color(22, 40, 32));
        f.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(210, 220, 215), 1),
                BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));
    }

    private JButton makeGreenButton(String text) {
        JButton btn = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                FontMetrics fm = g2.getFontMetrics(getFont());
                g2.setColor(Color.WHITE);
                g2.setFont(getFont());
                String t = getText();
                g2.drawString(t, (getWidth() - fm.stringWidth(t)) / 2,
                        (getHeight() + fm.getAscent() - fm.getDescent()) / 2);
                g2.dispose();
            }
        };
        btn.setBackground(new Color(34, 139, 87));
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("SansSerif", Font.BOLD, 13));
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(false);
        btn.setOpaque(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) { btn.setBackground(new Color(26, 110, 68)); }
            public void mouseExited(java.awt.event.MouseEvent e)  { btn.setBackground(new Color(34, 139, 87)); }
        });
        return btn;
    }

    private void doRegister() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();
        String role = (String) roleCombo.getSelectedItem();
        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields are required.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (password.length() < 4) {
            JOptionPane.showMessageDialog(this, "Password must be at least 4 characters.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (userDAO.usernameExists(username)) {
            JOptionPane.showMessageDialog(this, "Username already exists.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String newID = userDAO.generateNextUserID();
        User newUser = new User(newID, username, password, role);
        if (userDAO.register(newUser)) {
            JOptionPane.showMessageDialog(this, "Account registered successfully!\nYou can now login.", "Success", JOptionPane.INFORMATION_MESSAGE);
            dispose();
            parent.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this, "Registration failed. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
